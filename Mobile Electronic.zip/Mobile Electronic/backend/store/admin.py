from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User
from django.utils.html import format_html
from django.urls import reverse
from .models import Category, Product, Order, OrderItem, UserProfile, Wishlist, Review

# -----------------------------------------------------------------------------
# Category & Brand Management
# -----------------------------------------------------------------------------
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'parent', 'product_count', 'slug']
    list_filter = ['parent']
    search_fields = ['name']
    prepopulated_fields = {'slug': ('name',)}
    ordering = ['parent', 'name']

    def product_count(self, obj):
        return obj.products.count()
    product_count.short_description = 'Products'

# -----------------------------------------------------------------------------
# Product Management
# -----------------------------------------------------------------------------
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'price', 'stock', 'available', 'image_preview', 'updated']
    list_filter = ['available', 'category', 'created', 'updated']
    list_editable = ['price', 'stock', 'available']
    search_fields = ['name', 'description']
    prepopulated_fields = {'slug': ('name',)}
    date_hierarchy = 'created'
    actions = ['make_unavailable']

    def image_preview(self, obj):
        if obj.image:
            return format_html('<img src="{}" style="width: 50px; height: 50px; object-fit: contain;" />', obj.image.url)
        return "-"
    image_preview.short_description = "Image"

    def make_unavailable(self, request, queryset):
        queryset.update(available=False)
    make_unavailable.short_description = "Mark selected products as unavailable"

# -----------------------------------------------------------------------------
# Order Management
# -----------------------------------------------------------------------------
class OrderItemInline(admin.TabularInline):
    model = OrderItem
    raw_id_fields = ['product']
    extra = 0
    readonly_fields = ['price']

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'user_link', 'status', 'payment_status', 'payment_method', 'total_price', 'tracking_number', 'created_at']
    list_filter = ['status', 'payment_status', 'payment_method', 'created_at']
    search_fields = ['id', 'user__username', 'full_name', 'user__email', 'tracking_number']
    list_editable = ['status', 'payment_status', 'tracking_number']
    inlines = [OrderItemInline]
    actions = ['mark_confirmed', 'mark_shipped', 'mark_delivered', 'mark_paid']
    date_hierarchy = 'created_at'

    def user_link(self, obj):
        if obj.user:
            link = reverse("admin:auth_user_change", args=[obj.user.id])
            return format_html('<a href="{}">{}</a>', link, obj.user.username)
        return "Guest"
    user_link.short_description = "User"

    def mark_confirmed(self, request, queryset):
        queryset.update(status='CONFIRMED')
    mark_confirmed.short_description = "Mark as Confirmed"

    def mark_shipped(self, request, queryset):
        queryset.update(status='SHIPPED')
    mark_shipped.short_description = "Mark as Shipped"

    def mark_delivered(self, request, queryset):
        queryset.update(status='DELIVERED')
    mark_delivered.short_description = "Mark as Delivered"

    def mark_paid(self, request, queryset):
        queryset.update(payment_status='PAID')
    mark_paid.short_description = "Mark Payment as Paid"

# -----------------------------------------------------------------------------
# User Management
# -----------------------------------------------------------------------------
class UserProfileInline(admin.StackedInline):
    model = UserProfile
    can_delete = False
    verbose_name_plural = 'Profile'

class UserOrderInline(admin.TabularInline):
    model = Order
    fields = ['id', 'status', 'total_price', 'created_at']
    readonly_fields = ['id', 'status', 'total_price', 'created_at']
    extra = 0
    can_delete = False
    show_change_link = True

    def has_add_permission(self, request, obj):
        return False

# Unregister default User admin and register custom one
admin.site.unregister(User)

@admin.register(User)
class CustomUserAdmin(BaseUserAdmin):
    inlines = [UserProfileInline, UserOrderInline]
    list_display = ['username', 'email', 'first_name', 'last_name', 'is_active', 'is_staff', 'date_joined']
    list_filter = ['is_active', 'is_staff', 'date_joined']
    actions = ['block_users', 'unblock_users']

    def block_users(self, request, queryset):
        queryset.update(is_active=False)
    block_users.short_description = "Block selected users"

    def unblock_users(self, request, queryset):
        queryset.update(is_active=True)
    unblock_users.short_description = "Unblock selected users"

# -----------------------------------------------------------------------------
# Other
# -----------------------------------------------------------------------------
@admin.register(Wishlist)
class WishlistAdmin(admin.ModelAdmin):
    list_display = ['user', 'item_count']
    
    def item_count(self, obj):
        return obj.products.count()

@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ['product', 'user', 'rating', 'created_at']
    list_filter = ['rating', 'created_at']
