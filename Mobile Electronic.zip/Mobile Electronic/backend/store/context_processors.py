from .models import Category

def categories_processor(request):
    """
    Context processor to make all categories available in every template.
    Useful for the navigation bar dropdown.
    """
    return {
        'all_categories': Category.objects.filter(parent=None).prefetch_related('children')
    }
