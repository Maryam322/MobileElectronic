from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse
from django.views.decorators.http import require_POST
from django.contrib.auth import login as auth_login, logout as auth_logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.db.models import Q

from .models import Product, Category, Order, OrderItem, Wishlist, UserProfile
from .forms import SignUpForm, UserProfileForm

# -----------------------------------------------------------------------------
# Helper Functions
# -----------------------------------------------------------------------------

def get_cart_data(request):
    """
    Helper function to calculate cart totals and retrieve product details.
    Returns a tuple: (list of cart items with details, total price).
    """
    cart_session = request.session.get('cart', {})
    product_ids = cart_session.keys()
    products = Product.objects.filter(id__in=product_ids)
    
    cart_items = []
    total_price = 0
    
    for product in products:
        quantity = cart_session[str(product.id)]
        total = product.price * quantity
        total_price += total
        cart_items.append({
            'product': product,
            'quantity': quantity,
            'total': total,
            'price': product.price
        })
        
    return cart_items, total_price

# -----------------------------------------------------------------------------
# Cart & Checkout Views
# -----------------------------------------------------------------------------

@require_POST
def add_to_cart(request, product_id):
    """Adds a product to the shopping cart session."""
    cart = request.session.get('cart', {})
    product_id = str(product_id)
    if product_id in cart:
        cart[product_id] += 1
    else:
        cart[product_id] = 1
    request.session['cart'] = cart
    return redirect('store:cart')

def remove_from_cart(request, product_id):
    """Removes a product completely from the cart."""
    cart = request.session.get('cart', {})
    product_id = str(product_id)
    if product_id in cart:
        del cart[product_id]
        request.session['cart'] = cart
    return redirect('store:cart')

def remove_single_from_cart(request, product_id):
    """Decrements quantity of a product in the cart."""
    cart = request.session.get('cart', {})
    product_id = str(product_id)
    if product_id in cart:
        if cart[product_id] > 1:
            cart[product_id] -= 1
        else:
            del cart[product_id]
        request.session['cart'] = cart
    return redirect('store:cart')

def cart(request):
    """Renders shopping cart page."""
    cart_items, total_price = get_cart_data(request)
    return render(request, 'cart.html', {'cart_items': cart_items, 'total_price': total_price})

def checkout(request):
    """Renders checkout page with total price and user profile data."""
    _, total_price = get_cart_data(request)
    
    user_profile = None
    if request.user.is_authenticated:
        try:
             user_profile = UserProfile.objects.get(user=request.user)
        except UserProfile.DoesNotExist:
             pass
        
    return render(request, 'checkout.html', {'total_price': total_price, 'user_profile': user_profile})

@require_POST
def place_order(request):
    """Handles order creation logic."""
    cart_items, total_price = get_cart_data(request)
    
    if not cart_items:
        return redirect('store:cart')
        
    # Assign User or None (Guest)
    order_user = request.user if request.user.is_authenticated else None

    # Create Order
    order = Order.objects.create(
        user=order_user,
        full_name=request.POST.get('full_name'),
        address=request.POST.get('address'),
        city=request.POST.get('city'),
        postal_code=request.POST.get('postal_code'),
        total_price=total_price,
        payment_method=request.POST.get('payment_method'),
        status='PENDING'
    )
    
    # Create Order Items
    for item in cart_items:
        OrderItem.objects.create(
            order=order,
            product=item['product'],
            price=item['price'],
            quantity=item['quantity']
        )
        
    # Clear Cart
    request.session['cart'] = {}
    return redirect('store:order_confirmed', order_id=order.id)

def order_confirmed(request, order_id):
    """Renders order confirmation page."""
    order = get_object_or_404(Order, id=order_id)
    return render(request, 'order_confirmed.html', {'order': order})

def tracking(request):
    """Renders order tracking page."""
    return render(request, 'tracking.html')

# -----------------------------------------------------------------------------
# Auth Views
# -----------------------------------------------------------------------------

def login_view(request):
    """Handles user login."""
    if request.user.is_authenticated:
        return redirect('store:index')

    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            auth_login(request, user)
            next_url = request.GET.get('next') or 'store:index'
            # Security check for next_url
            if not next_url.startswith('/'):
                 next_url = 'store:index'
            return redirect(next_url)
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

def logout_view(request):
    """Logs out user."""
    auth_logout(request)
    return redirect('store:index')

def signup_view(request):
    """Handles user registration."""
    if request.user.is_authenticated:
        return redirect('store:index')
    
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, user)
            return redirect('store:index')
    else:
        form = SignUpForm()
    return render(request, 'signup.html', {'form': form})

@login_required
def profile(request):
    """Renders and updates user profile."""
    user_profile, created = UserProfile.objects.get_or_create(user=request.user)
    
    if request.method == 'POST':
        form = UserProfileForm(request.POST, instance=user_profile)
        if form.is_valid():
            form.save()
            return redirect('store:profile')
    else:
        form = UserProfileForm(instance=user_profile)
        
    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    
    return render(request, 'profile.html', {
        'form': form,
        'orders': orders,
        'user_profile': user_profile
    })

@login_required
def wishlist(request):
    """Renders wishlist page."""
    wishlist, created = Wishlist.objects.get_or_create(user=request.user)
    products = wishlist.products.all()
    return render(request, 'wishlist.html', {'products': products})

def add_to_wishlist(request, product_id):
    """Adds product to wishlist."""
    if not request.user.is_authenticated:
        return redirect(f"{reverse('store:login')}?next={request.path}")
    
    product = get_object_or_404(Product, id=product_id)
    wishlist, created = Wishlist.objects.get_or_create(user=request.user)
    wishlist.products.add(product)
    return redirect('store:wishlist')

def remove_from_wishlist(request, product_id):
    """Removes product from wishlist."""
    if not request.user.is_authenticated:
        return redirect('store:login')
        
    product = get_object_or_404(Product, id=product_id)
    wishlist = get_object_or_404(Wishlist, user=request.user)
    wishlist.products.remove(product)
    return redirect('store:wishlist')

# -----------------------------------------------------------------------------
# Shop Views
# -----------------------------------------------------------------------------

def index(request):
    """Renders home page."""
    products = Product.objects.filter(available=True)
    categories = Category.objects.all()
    return render(request, 'index.html', {'products': products, 'categories': categories})

def get_all_category_children(category):
    """Recursively retrieves all child categories."""
    children = [category]
    for child in category.children.all():
        children.extend(get_all_category_children(child))
    return children

def product_list(request, category_slug=None):
    """Renders product list with filtering and search."""
    category = None
    categories = Category.objects.all()
    products = Product.objects.filter(available=True)
    
    q = request.GET.get('q')
    if q:
        products = products.filter(
            Q(name__icontains=q) | 
            Q(description__icontains=q) |
            Q(category__name__icontains=q)
        )
    
    if category_slug:
        category = get_object_or_404(Category, slug=category_slug)
        all_categories = get_all_category_children(category)
        products = products.filter(category__in=all_categories)
        
    return render(request, 'product_list.html', {
        'category': category, 
        'categories': categories, 
        'products': products, 
        'search_query': q
    })

def product_detail(request, id, slug):
    """Renders product detail page."""
    product = get_object_or_404(Product, id=id, slug=slug, available=True)
    # Related products logic removed as per request
    return render(request, 'product_detail.html', {'product': product})

def about(request):
    """Renders about page."""
    return render(request, 'about.html')

def contact(request):
    """Renders contact page."""
    return render(request, 'contact.html')
