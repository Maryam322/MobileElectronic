
from django import template

register = template.Library()

@register.filter(name='currency_pkr')
def currency_pkr(value):
    """
    Formats a number into Pakistani rupees format (Lakh/Crore separaters).
    Example: 230000 -> 2,30,000
    """
    try:
        # Convert to float first to handle string decimals strings, then int if no decimal logic desired for main part
        # But prices are Decimal in models.
        val = int(value) 
    except (ValueError, TypeError):
        return value
    
    s = str(val)
    if len(s) <= 3:
        return s
        
    last_three = s[-3:]
    other = s[:-3]
    
    # Reverse string to process in chunks of 2
    other_rev = other[::-1]
    
    chunks = []
    for i in range(0, len(other_rev), 2):
        chunks.append(other_rev[i:i+2])
        
    res_rev = ",".join(chunks)
    res = res_rev[::-1]
    
    return res + "," + last_three
