# Mobile Electronic Store
A Django-based e-commerce website for mobile phones and accessories.

## Features
- **Product Management:** Browse products by categories (Phones, Accessories).
- **User Accounts:** Sign up, login, and manage user profiles with order history.
- **Shopping Cart:** Add items to cart, update quantities, and checkout.
- **Order System:** Place orders with multiple payment methods (COD, etc.).
- **Admin Panel:** Full dashboard for managing products, orders, and users.
- **Wishlist:** Save favorite items for later.

## Project Structure
The project is organized into two main directories:
- `backend/`: Contains the Django project code (`mobile_store`, `store` app, `db.sqlite3`).
- `frontend/`: Contains static assets (CSS, JS) and HTML templates.

## Setup Instructions

### Prerequisites
- Python 3.10+
- pip (Python package installer)

### Installation
1.  **Install Dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

2.  **Run Migrations:**
    Navigate to the `backend` folder and run:
    ```bash
    cd backend
    python manage.py migrate
    ```

3.  **Create Superuser (Admin):**
    ```bash
    python manage.py createsuperuser
    ```

4.  **Run Development Server:**
    ```bash
    python manage.py runserver
    ```
    Access the site at `http://127.0.0.1:8000/`.

## accounts
- **Admin Panel:** `http://127.0.0.1:8000/admin/`
  - Login with the superuser credentials created above.
